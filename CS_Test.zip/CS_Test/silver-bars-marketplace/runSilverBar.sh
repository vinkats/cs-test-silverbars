mvn clean install
java -jar target/silver-bars-marketplace-1.0-SNAPSHOT-jar-with-dependencies.jar

sleep 1m